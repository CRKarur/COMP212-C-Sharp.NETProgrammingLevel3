﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301163364_Karur__Lab4_Q1
{
    public class Menu
    {
        public Menu()
        {
            MenuList_Beverage = new ObservableCollection<MenuList>()
            {
                new MenuList() { Name = "Soda", Category = Category.Beverage, Price = 1.95, Id = 1 }
                ,new MenuList() { Name = "Tea", Category = Category.Beverage, Price = 1.50, Id = 2 }
                ,new MenuList() { Name = "Coffee", Category = Category.Beverage, Price = 1.25, Id = 3 }
                ,new MenuList() { Name = "Mineral Water", Category = Category.Beverage, Price = 2.95, Id = 4 }
                ,new MenuList() { Name = "Juice", Category = Category.Beverage, Price = 2.50, Id = 5 }
                ,new MenuList() { Name = "Milk", Category = Category.Beverage, Price = 1.50, Id = 6 }
            };
            MenuList_Appetizer = new ObservableCollection<MenuList>()
            {
                 new MenuList() { Name = "Buffalo Wings", Category = Category.Appetizer, Price = 5.95, Id = 7 }
                ,new MenuList() { Name = "Buffalo Fingers", Category = Category.Appetizer, Price = 6.95, Id = 8 }
                ,new MenuList() { Name = "Potato Skins", Category = Category.Appetizer, Price = 8.95, Id = 9 }
                ,new MenuList() { Name = "Nachos", Category = Category.Appetizer, Price = 8.95, Id = 10 }
                ,new MenuList() { Name = "Mushroom Caps", Category = Category.Appetizer, Price = 10.95, Id = 11 }
                ,new MenuList() { Name = "Shrimp Cocktail", Category = Category.Appetizer, Price = 12.95, Id = 12 }
                ,new MenuList() { Name = "Chips and Sala", Category = Category.Appetizer, Price = 6.95, Id = 13 }
            };
            MenuList_MainCourse = new ObservableCollection<MenuList>()
            {
                new MenuList() { Name = "Seafood Alfredo", Category = Category.MainCourse, Price = 15.95, Id = 14 }
                ,new MenuList() { Name = "Chicken Alfredo", Category = Category.MainCourse, Price = 13.95, Id = 15 }
                ,new MenuList() { Name = "Turkey Club", Category = Category.MainCourse, Price = 11.95, Id = 17 }
                ,new MenuList() { Name = "Lobster Pie", Category = Category.MainCourse, Price = 19.95, Id = 18 }
                ,new MenuList() { Name = "Prime Rib", Category = Category.MainCourse, Price = 20.95, Id = 19 }
                ,new MenuList() { Name = "Shrimp Scampi", Category = Category.MainCourse, Price = 18.95, Id = 20 }
                ,new MenuList() { Name = "Turkey Dinner", Category = Category.MainCourse, Price = 13.95, Id = 21 }
                ,new MenuList() { Name = "Stuffed Chicken", Category = Category.MainCourse, Price = 14.95, Id = 22 }
            };
            MenuList_Dessert = new ObservableCollection<MenuList>()
            {
                 new MenuList() { Name = "Apple Pie", Category = Category.Dessert, Price = 5.95, Id = 23 }
                ,new MenuList() { Name = "Sundae", Category = Category.Dessert, Price = 3.95, Id = 24 }
                ,new MenuList() { Name = "Carrot Cake", Category = Category.Dessert, Price = 5.95, Id = 25 }
                ,new MenuList() { Name = "Mud Pie", Category = Category.Dessert, Price = 4.95, Id = 26 }
                ,new MenuList() { Name = "Apple Crisp", Category = Category.Dessert, Price = 5.95, Id = 27 }
            };
        }
        #region Beverage
        private ObservableCollection<MenuList> _menulist_Beverage;
        public ObservableCollection<MenuList> MenuList_Beverage
        {
            get { return _menulist_Beverage; }
            set { _menulist_Beverage = value; }
        }
        private MenuList _smenulist;
        public MenuList SMenuList
        {
            get { return _smenulist; }
            set { _smenulist = value; }
        }
        #endregion
        #region Appetizer
        private ObservableCollection<MenuList> _menulist_Appetizer;
        public ObservableCollection<MenuList> MenuList_Appetizer
        {
            get { return _menulist_Appetizer; }
            set { _menulist_Appetizer = value; }
        }
        #endregion
        #region MainCourse
        private ObservableCollection<MenuList> _menulist_MainCourse;
        public ObservableCollection<MenuList> MenuList_MainCourse
        {
            get { return _menulist_MainCourse; }
            set { _menulist_MainCourse = value; }
        }
        #endregion
        #region Dessert
        private ObservableCollection<MenuList> _menulist_Dessert;
        public ObservableCollection<MenuList> MenuList_Dessert
        {
            get { return _menulist_Dessert; }
            set { _menulist_Dessert = value; }
        }
        #endregion
    }
}
