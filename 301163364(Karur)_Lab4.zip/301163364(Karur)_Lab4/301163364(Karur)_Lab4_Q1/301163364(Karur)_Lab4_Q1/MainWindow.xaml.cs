﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _301163364_Karur__Lab4_Q1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<BillList> SelectedDished = new List<BillList>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            Regex regex = new Regex("[^0-9]+");
            e.Handled = regex.IsMatch(e.Text);
        }
        private void resetComboBox()
        {
            this.cmbBeverage.SelectedIndex = -1;
            this.cmbAppetizer.SelectedIndex = -1;
            this.cmbMainCourse.SelectedIndex = -1;
            this.cmbDessert.SelectedIndex = -1;
            calculateTotal();
        }
        private void updateItemQty(BillList bill_Item)
        {
            var insertAt = this.dgBillList.Items.IndexOf(bill_Item);
            this.dgBillList.Items.Remove(bill_Item);
            this.dgBillList.Items.Insert(insertAt, new BillList
            {
                Id = bill_Item.Id,
                Category = bill_Item.Category,
                Name = bill_Item.Name,
                Price = bill_Item.Price,
                Qty = ++bill_Item.Qty,
            });
            calculateTotal();
        }
        private void AddItem(BillList bill_Item)
        {
            this.dgBillList.Items.Add(new BillList
            {
                Id = bill_Item.Id,
                Category = bill_Item.Category,
                Name = bill_Item.Name,
                Price = bill_Item.Price,
                Qty = 1,
            });
            calculateTotal();
        }
        private void calculateTotal()
        {
            decimal subTotal = 0;
            decimal tax = 0;
            for (int i = 0; i < this.dgBillList.Items.Count; i++)
            {
                var item = (BillList)this.dgBillList.Items[i];
                subTotal += (decimal)(item.Qty * item.Price);
            }
            tax = (decimal)0.05 * subTotal;

            lblValueSubtotal.Content = "$" + Math.Round(subTotal,2);
            lblValueTax.Content = "$" + Math.Round((decimal)tax,2);
            lblValueTotal.Content = "$" + Math.Round((decimal)(subTotal + tax),2);
        }
        private void AddItemInBillDataGrid_Executed(object sender, ExecutedRoutedEventArgs e)
        {

            if (this.cmbBeverage.SelectedItem != null)
            {
                var v1 = (MenuList)this.cmbBeverage.SelectedItem;
                var isNamePresent = dgBillList.Items.Cast<BillList>().Any(item => item.Name == v1.Name);
                if (isNamePresent)
                {
                    updateItemQty(this.dgBillList.Items.Cast<BillList>().Where(item => item.Name == v1.Name).FirstOrDefault());
                }
                else
                {
                    AddItem(new BillList { Id = v1.Id, Category = v1.Category, Name = v1.Name, Price = v1.Price, Qty = 1 });
                }
            }

            if (this.cmbAppetizer.SelectedItem != null)
            {
                var v1 = (MenuList)this.cmbAppetizer.SelectedItem;
                var isNamePresent = dgBillList.Items.Cast<BillList>().Any(item => item.Name == v1.Name);
                if (isNamePresent)
                {
                    updateItemQty(this.dgBillList.Items.Cast<BillList>().Where(item => item.Name == v1.Name).FirstOrDefault());
                }
                else
                {
                    AddItem(new BillList { Id = v1.Id, Category = v1.Category, Name = v1.Name, Price = v1.Price, Qty = 1 });
                }

            }
            if (this.cmbMainCourse.SelectedItem != null)
            {
                var v1 = (MenuList)this.cmbMainCourse.SelectedItem;
                var isNamePresent = dgBillList.Items.Cast<BillList>().Any(item => item.Name == v1.Name);

                if (isNamePresent)
                {
                    updateItemQty(this.dgBillList.Items.Cast<BillList>().Where(item => item.Name == v1.Name).FirstOrDefault());
                }
                else
                {
                    AddItem(new BillList { Id = v1.Id, Category = v1.Category, Name = v1.Name, Price = v1.Price, Qty = 1 });
                }
            }
            if (this.cmbDessert.SelectedItem != null)
            {
                var v1 = (MenuList)this.cmbDessert.SelectedItem;
                var isNamePresent = dgBillList.Items.Cast<BillList>().Any(item => item.Name == v1.Name);

                if (isNamePresent)
                {
                    updateItemQty(this.dgBillList.Items.Cast<BillList>().Where(item => item.Name == v1.Name).FirstOrDefault());
                }
                else
                {
                    AddItem(new BillList { Id = v1.Id, Category = v1.Category, Name = v1.Name, Price = v1.Price, Qty = 1 });
                }
            }
            this.dgBillList.Items.Refresh();
            resetComboBox();
        }

        private void CommandBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            this.dgBillList.Items.Clear();
            resetComboBox();

        }

        private void RemoveItemInBillDataGrid_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (dgBillList.SelectedItem != null)
            {
                dgBillList.Items.Remove(dgBillList.SelectedItem);
                calculateTotal();
            }
            else
            {
                if (dgBillList.Items.Count > 0)
                {
                    MessageBox.Show("Please select item from Bill tray..", "Alert");
                }
            }
        }


        private void txtQty_TextChanged(object sender, TextChangedEventArgs e)
        {
            var insertAt = this.dgBillList.Items.IndexOf(dgBillList.SelectedItem);
            if (insertAt >= 0)
            {
                TextBox txt = (TextBox)sender;
                var item = (BillList)dgBillList.SelectedItem;
                this.dgBillList.Items.Remove(item);
                this.dgBillList.Items.Insert(insertAt, new BillList
                {
                    Id = item.Id,
                    Category = item.Category,
                    Name = item.Name,
                    Price = item.Price,
                    Qty = Convert.ToInt32(txt.Text),
                });
            }
            calculateTotal();
        }

    }
    public static class CustomCommands
    {
        public static readonly RoutedUICommand AddItemInBillDataGrid = new RoutedUICommand
            (
                "AddItemInBillDataGrid",
                "AddItemInBillDataGrid",
                typeof(CustomCommands),
                new InputGestureCollection()
                {
                    //new KeyGesture(Key.F4, ModifierKeys.Alt)
                }
            );
        public static readonly RoutedUICommand ClearItemInBillDataGrid = new RoutedUICommand
            (
                "ClearItemInBillDataGrid",
                "ClearItemInBillDataGrid",
                typeof(CustomCommands),
                new InputGestureCollection()
                {
                    //new KeyGesture(Key.F4, ModifierKeys.Alt)
                }
            );
        public static readonly RoutedUICommand RemoveItemInBillDataGrid = new RoutedUICommand
            (
                "RemoveItemInBillDataGrid",
                "RemoveItemInBillDataGrid",
                typeof(CustomCommands),
                new InputGestureCollection()
                {
                    //new KeyGesture(Key.F4, ModifierKeys.Alt)
                }
            );

        //Define more commands here, just like the one above
    }
}