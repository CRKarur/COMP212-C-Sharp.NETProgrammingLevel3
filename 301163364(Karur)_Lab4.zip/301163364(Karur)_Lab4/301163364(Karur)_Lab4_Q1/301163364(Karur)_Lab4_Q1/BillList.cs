﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301163364_Karur__Lab4_Q1
{
    public class BillList
    {
        private int _id;
        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private double _price;

        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }
        private Category _category;

        public Category Category
        {
            get { return _category; }
            set { _category = value; }
        }
        private int _qty;

        public int Qty
        {
            get { return _qty; }
            set { _qty = value; }
        }

        private bool _isSelected;

        public bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; }
        }
    }
}
