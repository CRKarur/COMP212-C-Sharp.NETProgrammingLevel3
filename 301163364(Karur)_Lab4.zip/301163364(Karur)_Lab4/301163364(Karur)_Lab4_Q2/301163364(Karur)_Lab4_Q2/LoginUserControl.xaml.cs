using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _301163364_Karur__Lab4_Q2
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class LoginUserControl : UserControl
    {
        public LoginUserControl()
        {
            InitializeComponent();
        }

        public string RequiredSymbol
        {
            get { return (string)GetValue(RequiredSymbolProperty); }
            set { SetValue(RequiredSymbolProperty, value); }
        }

        public static readonly DependencyProperty RequiredSymbolProperty =
             DependencyProperty.Register("RequiredSymbol", typeof(string), typeof(LoginUserControl), new PropertyMetadata("*"));

        public string LabelText
        {
            get { return (string)GetValue(LabelTextProperty); }
            set { SetValue(LabelTextProperty, value); }
        }

        public static readonly DependencyProperty LabelTextProperty =
            DependencyProperty.Register("LabelText", typeof(string), typeof(LoginUserControl), new PropertyMetadata(string.Empty));

        public bool IsRequired
        {
            get { return (bool)GetValue(IsRequiredProperty); }
            set { SetValue(IsRequiredProperty, value); }
        }

        public static readonly DependencyProperty IsRequiredProperty =
                   DependencyProperty.Register("IsRequired", typeof(bool), typeof(LoginUserControl), new PropertyMetadata(true, OnRequiredChange));

        private static void OnRequiredChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            LoginUserControl ctrl = d as LoginUserControl;
            if ((bool)e.NewValue == false)
                ctrl.RequiredSymbol = string.Empty;
        }
    }
}