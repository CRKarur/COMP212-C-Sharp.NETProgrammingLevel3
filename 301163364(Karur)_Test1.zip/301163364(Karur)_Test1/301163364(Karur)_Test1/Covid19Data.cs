﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _301163364_Karur__Test1
{
    public class Covid19Data
    {
        public string ps { get; set; }
        public string cr { get; set; }
        public string date { get; set; }
        public string rn { get; set; }
    }


}
