﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _301163364_Karur__Test1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
           
        }

        private async void DisplayCovid19Data(object sender, RoutedEventArgs e)
        {
            System.Windows.Data.CollectionViewSource collectionViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("Covid19DataGrid")));
            Task<List<Covid19Data>> DisplayTask = Task.Run(() => ReadData(@"D:\Winter 2021\COMP212-C#.NET\Lab Assignments\MidTerm\Test#1\Test#1\covid19_recovered_global.csv"));
            await DisplayTask;
            Covid19DataGrid.DataContext = DisplayTask.Result;
        }

        public List<Covid19Data> ReadData(string fp)
        {

            string[] filedata = File.ReadAllLines(fp);
            var row_count = filedata.Length;
            string[] rowdata0 = filedata[0].Split(',');
            var col_count = rowdata0.Length;
            Console.WriteLine("No of rows = {0}, cols = {1}", row_count, col_count);
            List<Covid19Data> CovidDataList = new List<Covid19Data>();


            string[] rowdata;

            for (int r=1; r<row_count; r++)
            {
                rowdata = filedata[r].Split(',');

                for (int c=2; c<col_count; c++)
                {
                    Covid19Data CovidDataToAdd = new Covid19Data();
                    CovidDataToAdd.ps = rowdata[0];
                    CovidDataToAdd.cr = rowdata[1];
                    CovidDataToAdd.date = rowdata0[c];
                    CovidDataToAdd.rn = rowdata[c];
                    if (!CovidDataToAdd.rn.Equals("0")) {
                        CovidDataList.Add(CovidDataToAdd);
                    }
                    
                } 

            }
            return CovidDataList;
        }

        private void Combo_CR_Load(object sender, RoutedEventArgs e)
        {
            StreamReader sr = new StreamReader(@"D:\Winter 2021\COMP212-C#.NET\Lab Assignments\MidTerm\Test#1\Test#1\Covid19_Country.txt");
            string line = sr.ReadLine();
            while (line != null)
            {
                Combo_CR.Items.Add(line);
                line = sr.ReadLine();
            }
        }

        private async void Insert_btn_Click(object sender, RoutedEventArgs e)
        {
            string country = Combo_CR.Text;
            string state = Text_PS.Text;
            string date = Pick_Date.ToString();
            string recovered = Text_RN.Text;
            Console.WriteLine("inputs" + country + " " + state + " " + date + " " + recovered);
            System.Windows.Data.CollectionViewSource collectionViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("Covid19DataGrid")));
            Task<List<Covid19Data>> InsertTask = Task.Run(() => InsertData(@"D:\Winter 2021\COMP212-C#.NET\Lab Assignments\MidTerm\Test#1\Test#1\covid19_recovered_global.csv", country, state, date, recovered));
            await InsertTask;
            Covid19DataGrid.DataContext = InsertTask.Result;
            Covid19DataGrid.Focus();
        }

        public List<Covid19Data> InsertData(string fp, string cn, string st, string dt, string rn)
        {
            string[] filedata = File.ReadAllLines(fp);
            var row_count = filedata.Length;
            string[] rowdata0 = filedata[0].Split(',');
            var col_count = rowdata0.Length;
            Console.WriteLine("No of rows = {0}, cols = {1}", row_count, col_count);
            List<Covid19Data> CovidDataList = new List<Covid19Data>();

            string[] rowdata;
            string[] datestr = dt.Split(' ');
            
            for (int r = 1; r < row_count; r++)
            {
                rowdata = filedata[r].Split(',');

                for (int c = 2; c < col_count; c++)
                {
                    Covid19Data CovidDataToAdd = new Covid19Data();
                    CovidDataToAdd.ps = rowdata[0];
                    CovidDataToAdd.cr = rowdata[1];
                    CovidDataToAdd.date = rowdata0[c];
                    CovidDataToAdd.rn = rowdata[c];
                    if (!CovidDataToAdd.rn.Equals("0"))
                    {
                        CovidDataList.Add(CovidDataToAdd);
                    }
                }

            }
            Covid19Data CovidDataToAdd2 = new Covid19Data();
            CovidDataToAdd2.ps = st; //rowdata[0];
            CovidDataToAdd2.cr = cn;  //rowdata[1];
            CovidDataToAdd2.date = dt; // rowdata0[c];
            CovidDataToAdd2.rn = rn; // rowdata[c]; 
            CovidDataList.Add(CovidDataToAdd2);
            
            
            return CovidDataList;
        }


    }
}
