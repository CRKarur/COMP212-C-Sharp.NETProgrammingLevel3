﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlickrViewer
{
    public class Parallel
{
        public static byte[] imageBytes;
        public static int height;
        public static int width;
        public static string imageFileName;
        public static void CreateSaveThumbNail(byte[] imageBytes, int width, string imageFileName)
        {
            using (var stream = new MemoryStream(imageBytes))
            {
                width /= 2;
                var image = Image.FromStream(stream);
                var height = (width * image.Height) / image.Width;
                var thumbnail = image.GetThumbnailImage(width, height, null, IntPtr.Zero);
                using (var thumbnailStream = new MemoryStream())
                {
                    thumbnail.Save(imageFileName + "thumbnail.jpg", ImageFormat.Jpeg);


                }
            }
            MessageBox.Show("Thumbnail Saved");
        }

        public static void CreateSaveImage(byte[] imageBytes, string FileName)
        {
            using (var stream = new MemoryStream(imageBytes))
            {

                var image = Image.FromStream(stream);

                using (var thumbnailStream = new MemoryStream())
                {
                    image.Save(imageFileName + "Image.jpg", ImageFormat.Jpeg);


                }
            }
            MessageBox.Show("Image Saved");
        }
    }
}
