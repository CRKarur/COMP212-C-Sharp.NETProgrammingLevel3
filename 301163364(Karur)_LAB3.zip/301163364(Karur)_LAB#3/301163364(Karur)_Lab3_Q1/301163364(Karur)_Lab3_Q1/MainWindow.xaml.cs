﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _301163364_Karur__Lab3_Q1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Data.CollectionViewSource StockDataGridView = ((System.Windows.Data.CollectionViewSource)(this.FindResource("stockDataGridView")));
        }

        private async void Search_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Data.CollectionViewSource StockDataGridView = ((System.Windows.Data.CollectionViewSource)(this.FindResource("stockDataGridView")));

            string company = SearchField.Text;
            Loading_Info.Content = "Loading.";
            Task<List<StockData>> searchTask = Task.Run(() => this.Search_List(@"D:\Winter 2021\COMP212-C#.NET\Lab Assignments\Lab3\301163364(Karur)_LAB#3\301163364(Karur)_Lab3_Q1\301163364(Karur)_Lab3_Q1\stockData.csv", company));
            Loading_Info.Content = "";
            await searchTask;

            if (searchTask.Result.Count > 0)
            {
                StockDataGridView.Source = searchTask.Result;
            }
            else
            {
                MessageBox.Show("No data found for this company!");
            }
        }

        public List<StockData> Search_List(string fp, string company)
        {
            var rows = File.ReadAllLines(fp);
            var data = from result in rows.Skip(1)
                       let split = result.Split(',')
                       where split[0].Equals(company)
                       where !split[2].Contains("(") && !split[3].Contains("(") && !split[4].Contains("(") && !split[5].Contains("(")
                       where !split[2].StartsWith("\"") && !split[3].StartsWith("\"")
                       && !split[4].StartsWith("\"") && !split[5].StartsWith("\"")
                       select new StockData
                       {
                           Company = split[0],
                           Date = split[1],
                           Open = split[2],
                           High = split[3],
                           Low = split[4],
                           Close = split[5]
                       };

           //making the thread sleep to paralelly run factorial calculation
            Thread.Sleep(4000);
            
            //sorts list of stock data
            var sortedData= data.OrderBy(x => x.Date);

            return sortedData.ToList();
        }


        private void Calculate_Click(object sender, RoutedEventArgs e)
        {
            int number = int.Parse(FactorialInput.Text);
            double answer = 1;
            while (number > 1)
            {
                answer = answer * number;
                number = number - 1;
            }
            FactorialAnswer.Content =  FactorialInput.Text + "! = " + answer;
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            stockDataGridView.DataContext = null;
        }
    }
}
